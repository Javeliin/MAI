#include <stdio.h>
#include <iostream>
#include "vector.hpp"

using namespace NVector;

struct Post {
    unsigned long long value;
    unsigned int key;
};

const int RANGE = 1000000;

void Sorrt(TVector<Post>& source);

int main() {
    TVector <Post> postList;
    Post tmp;

    while (scanf("%u\t%llu\n", &tmp.key, &tmp.value) == 2) {
        postList.PushBack(tmp);
    }

    Sorrt(postList);

    for (int i = 0; i < postList.Size(); ++i) {
        printf("%u\t%llu\n", postList[i].key, postList[i].value);
    }
    return 0;
}

void Sorrt(TVector<Post>& source) {
    int count[RANGE]{0};
    TVector <Post> result(source.Size());

    for (int i = 0; i < source.Size(); ++i) {
        ++count[source[i].key];
    }

    for (int i = 1; i < RANGE; ++i) {
        count[i] += count[i - 1];
    }

    for (int i = source.Size() - 1; i >= 0; --i) {
        result[--count[source[i].key]] = source[i];
    }
    Swap(result, source);
}
